# 設計來源與採用理由

資料觀察日期：2026-09-05（UTC）。下列版本與星數由 GitHub API 及固定版本檔案核對；星數只是可重查的觀察值，不是有效性、維護品質或適用性的證明。

本套件研究五套 OKR 實作及三套成熟 skill 專案的相關文件，以目前需求重新撰寫執行規則；沒有把上游 skill 原文、程式碼或私人的需求對話打包。參考來源的授權屬於各來源；本套件的 MIT 授權不替未獲授權的第三方材料重新授權。

| 來源 | 固定版本 | 觀察時 stars | 已核對授權 |
|---|---|---:|---|
| [OKRClaw](https://github.com/agenmod/okr-skill) | [d826167d8d6d](https://github.com/agenmod/okr-skill/tree/d826167d8d6d5ec537b3b3fe2a9f561aef6e9c37) | 6 | MIT |
| [OKR Skill Coach](https://github.com/BridgeLogicsProjects/okr-skill-coach) | [9ab2320e2ec1](https://github.com/BridgeLogicsProjects/okr-skill-coach/tree/9ab2320e2ec1efca68978ecce4bad580ca6e92c2) | 0 | MIT |
| [OrchestKit / okr-design](https://github.com/yonatangross/orchestkit) | [5ccf3bbed4b2](https://github.com/yonatangross/orchestkit/tree/5ccf3bbed4b2bdc93eb0caa2dc4dc58d4c26de54) | 229 | MIT |
| [Forge OKR Skill](https://github.com/peterfei/forge-skill-okr-skill) | [96df238aa1ce](https://github.com/peterfei/forge-skill-okr-skill/tree/96df238aa1cea02cfae939c59374749a28c0b911) | 0 | 固定版本未找到授權檔；僅研究 |
| [OKR Creator](https://github.com/chainreactors/okr-creator) | [6db9fb53a93c](https://github.com/chainreactors/okr-creator/tree/6db9fb53a93cdcc877ae8d99de0a5a391d1ca073) | 10 | MIT |
| [Superpowers](https://github.com/obra/superpowers) | [b36e0829c6d0](https://github.com/obra/superpowers/tree/b36e0829c6d0140e93cfef2ca599b1b07d4a7797) | 281,999 | MIT |
| [Anthropic skill-creator](https://github.com/anthropics/skills) | [41bbe19d1a1a](https://github.com/anthropics/skills/tree/41bbe19d1a1a7eaab5e7bb9050a417e5c6cffc8f) | 174,448 | Apache-2.0（所讀 skill 目錄） |
| [OpenAI skill-creator](https://github.com/openai/skills) | [49f948faa925](https://github.com/openai/skills/tree/49f948faa9258a0c61caceaf225e179651397431) | 25,441 | Apache-2.0（所讀 skill 目錄） |

## OKRClaw

- 採用的方法：制定、對齊、追蹤、評分、回顧的完整生命週期。
- 沒有沿用：固定 KR 數量、廣泛自動觸發、把 0.6–0.7 當普遍及格線。
- 查閱的固定版本文件：
  - [SKILL.md](https://github.com/agenmod/okr-skill/blob/d826167d8d6d5ec537b3b3fe2a9f561aef6e9c37/SKILL.md)
  - [LICENSE](https://github.com/agenmod/okr-skill/blob/d826167d8d6d5ec537b3b3fe2a9f561aef6e9c37/LICENSE)

## OKR Skill Coach

- 採用的方法：依階段分工；結果與活動分開；保留原目標、調整理由與信心判斷。
- 沒有沿用：每次都追問、固定週期；直接以目前值除目標套用所有指標；平均分數掩蓋底線。
- 查閱的固定版本文件：
  - [okr-coach/SKILL.md](https://github.com/BridgeLogicsProjects/okr-skill-coach/blob/9ab2320e2ec1efca68978ecce4bad580ca6e92c2/okr-coach/SKILL.md)
  - [okr-check-in-coach/SKILL.md](https://github.com/BridgeLogicsProjects/okr-skill-coach/blob/9ab2320e2ec1efca68978ecce4bad580ca6e92c2/okr-check-in-coach/SKILL.md)
  - [okr-retrospective-coach/SKILL.md](https://github.com/BridgeLogicsProjects/okr-skill-coach/blob/9ab2320e2ec1efca68978ecce4bad580ca6e92c2/okr-retrospective-coach/SKILL.md)
  - [LICENSE](https://github.com/BridgeLogicsProjects/okr-skill-coach/blob/9ab2320e2ec1efca68978ecce4bad580ca6e92c2/LICENSE)

## OrchestKit / okr-design

- 採用的方法：定義量測口徑、辨識領先／落後指標與必要底線；按需讀取細節。
- 沒有沿用：Claude 專屬欄位及固定指標配額；不因框架有工具就增加本套件依賴。
- 查閱的固定版本文件：
  - [plugins/ork/skills/okr-design/SKILL.md](https://github.com/yonatangross/orchestkit/blob/5ccf3bbed4b2bdc93eb0caa2dc4dc58d4c26de54/plugins/ork/skills/okr-design/SKILL.md)
  - [LICENSE](https://github.com/yonatangross/orchestkit/blob/5ccf3bbed4b2bdc93eb0caa2dc4dc58d4c26de54/LICENSE)

## Forge OKR Skill

- 採用的方法：審視結果、日常工作與策略的界線，作為設計比較。
- 沒有沿用：固定挑戰型比例或一概否定二元能力結果；未找到授權檔，不複製或散布其內容。
- 查閱的固定版本文件：
  - [SKILL.md](https://github.com/peterfei/forge-skill-okr-skill/blob/96df238aa1cea02cfae939c59374749a28c0b911/SKILL.md)

## OKR Creator

- 採用的方法：先讀專案再規劃；每項 KR 都要有可操作的驗證方式。
- 沒有沿用：將專案狀態寫進可重用 skill、強制全套診斷與季度配額、預設部署 Actions/API，以及羞辱式語氣。
- 查閱的固定版本文件：
  - [LICENSE](https://github.com/chainreactors/okr-creator/blob/6db9fb53a93cdcc877ae8d99de0a5a391d1ca073/LICENSE)
  - [.claude/skills/okr/SKILL.md](https://github.com/chainreactors/okr-creator/blob/6db9fb53a93cdcc877ae8d99de0a5a391d1ca073/.claude/skills/okr/SKILL.md)
  - [skills/okr-creator/SKILL.md](https://github.com/chainreactors/okr-creator/blob/6db9fb53a93cdcc877ae8d99de0a5a391d1ca073/skills/okr-creator/SKILL.md)

## Superpowers

- 採用的方法：以實際證據支持完成聲明；用獨立情境檢查 skill 是否真的改變執行行為。
- 沒有沿用：每個小任務都重新批准、所有狀態更新都要求全量重跑、整套工作流依賴。
- 查閱的固定版本文件：
  - [skills/verification-before-completion/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/verification-before-completion/SKILL.md)
  - [skills/writing-skills/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/writing-skills/SKILL.md)
  - [skills/executing-plans/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/executing-plans/SKILL.md)
  - [skills/brainstorming/SKILL.md](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/skills/brainstorming/SKILL.md)
  - [LICENSE](https://github.com/obra/superpowers/blob/b36e0829c6d0140e93cfef2ca599b1b07d4a7797/LICENSE)

## Anthropic skill-creator

- 採用的方法：用實際任務、產出與可判讀條件做行為驗證；控制上下文量，按需讀取附檔。
- 沒有沿用：不綁定其平台專屬評測工具；本次沒有完成跨模型或無 skill 對照實驗，故不宣稱這些結果。
- 查閱的固定版本文件：
  - [skills/skill-creator/SKILL.md](https://github.com/anthropics/skills/blob/41bbe19d1a1a7eaab5e7bb9050a417e5c6cffc8f/skills/skill-creator/SKILL.md)
  - [skills/skill-creator/LICENSE.txt](https://github.com/anthropics/skills/blob/41bbe19d1a1a7eaab5e7bb9050a417e5c6cffc8f/skills/skill-creator/LICENSE.txt)

## OpenAI skill-creator

- 採用的方法：SKILL.md 與宿主中介資料分工、漸進載入、精簡資源與格式驗證。
- 沒有沿用：不把格式通過當成可用性通過；因公開下載需求，Repository 另附 README，安裝包則保留授權、來源及驗證文件。
- 查閱的固定版本文件：
  - [skills/.system/skill-creator/SKILL.md](https://github.com/openai/skills/blob/49f948faa9258a0c61caceaf225e179651397431/skills/.system/skill-creator/SKILL.md)
  - [skills/.system/skill-creator/LICENSE.txt](https://github.com/openai/skills/blob/49f948faa9258a0c61caceaf225e179651397431/skills/.system/skill-creator/LICENSE.txt)

## OKR 原則與宿主文件

- [Google’s OKR Playbook（What Matters 授權刊載）](https://www.whatmatters.com/resources/google-okr-playbook)：核對可衡量結果、可核驗證據，以及承諾型／挑戰型目標的差別。沒有把其中的企業評分慣例設定為所有專案的及格線。
- [ChatGPT：Build skills](https://learn.chatgpt.com/docs/build-skills) 與 [Skills and plugins](https://learn.chatgpt.com/docs/skills-and-plugins)：核對 skill 結構及在宿主使用的概念；客戶端功能以當時實際可用入口為準。

## 本套件的整合選擇

本套件組合「OKR 結果邏輯＋情境驗收＋依具體風險安排的檢核點」。其中真實使用回饋、跨回合啟用約定、可繼續的獨立工作、證據版本與範圍，是為了讓代理執行可以被及時驗證而明確化的設計；不宣稱這是一套已有正式認證的標準框架。

授權檔僅作查閱與來源標示；本套件未附上第三方 skill 原文。若後續維護者直接納入第三方程式或文字，應另核對並保留該材料要求的授權與標示。
