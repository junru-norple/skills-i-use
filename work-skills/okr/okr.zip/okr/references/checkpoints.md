# Checkpoints that change a decision

Read before creating a staged execution plan or deciding whether to move past a checkpoint.

## Place checks before avoidable rework

Use the consequence of being wrong, not a fixed number of files, days, or completed tasks. Identify dependencies first. A checkpoint is useful if its outcome changes what should happen next.

| Situation | Proportionate check | Work dependent on passing |
|---|---|---|
| Repeating a new design or content pattern | Review one representative usable sample, including a difficult case | Large-scale repetition of that pattern |
| Several parts must work together | Exercise the critical end-to-end path and a consequential failure/recovery case | Work that assumes the integration works |
| Small, reversible local fix | A focused check of the changed behavior | Delivery of that fix; no extra planning approval by default |
| Existing accepted behavior changes | Test and, where relevant, obtain human feedback on the affected behavior | Claims that the changed behavior is accepted |
| Research or analysis | Validate a decision-relevant claim against traceable evidence and uncertainty | Conclusions or actions depending on that claim |
| Packaging or release | Inspect the actual artifact against applicable acceptance and authorization | Final delivery/release claims; distinguish trial packages |

Merge overlapping checks. Retain separate human and technical decisions even if they share a checkpoint. Do not spread superficial approvals across every component, insist on a fixed three-stage pipeline, or rerun unrelated checks after a change that cannot affect them. Honor meaningful existing project gates without manufacturing new ones.

Capture each checkpoint concisely:

`ID | risk caught | trigger | artifact/version | pass condition | evaluator | evidence/status | dependent work`

The trigger might be “before generating the remaining pages,” not a calendar date. Every checkpoint must name the meaningful failure it can catch. If that answer is empty, remove or merge it.

## Agent verification

Run available, relevant checks and inspect actual results. Passing a file-existence check proves existence, not usability. A screenshot proves rendered appearance in its captured conditions, not successful interaction. A valid YAML file proves parsing, not reliable skill behavior.

Record enough to reproduce or evaluate the evidence: artifact/version, procedure or command, conditions/data, actual result, and run/date reference. Distinguish direct observation, user-reported observation, inference, planned checks, and unavailable checks. Do not claim to have run a command or opened a trial that was not run or opened.

Fix a demonstrated problem within agreed scope, then rerun the affected check and any concretely exposed dependency. An unchanged evidence item may remain valid; avoid requiring a full rerun merely to repeat a status update.

If a check fails, inspect the cause. If an attempted fix fails again, revise the hypothesis using new evidence rather than repeating it blindly. Ask the user only when a material choice, access, or observation is needed. Name the specific dependency blocked; continue other authorized work when it remains useful.

## Real-use acceptance

When the requirement concerns operation, interaction, reader comprehension, or experience, use the user's real trial for acceptance. Prepare a usable sample first. For a document, this can be a reader performing its intended task; for a skill, it can be an actual conversation; for an app, it can be the core flow and recovery path.

Provide:

1. The accessible trial artifact and its version or identifiable state.
2. Two to four steps that exercise the agreed task.
3. The specific observation needed to decide the pending scope.

Record the user's feedback and what it covers. An answer such as “I tried v2's create-and-edit flow; saving worked but errors are confusing” contains both accepted and failed aspects. Do not demand a special confirmation word when the user has already supplied sufficient actual feedback. “Looks fine” after a screenshot or “go ahead” before trying is not evidence that a real-use test occurred.

Do not turn silence, an unavailable user, a predicted preference, or automated success into acceptance. Set the human check to pending, identify dependent work, and continue independent authorized work. A limited successful trial does not approve other flows, platforms, or later changed behavior.

Reaccept materially changed behavior; preserve unaffected evidence and accepted scope. Trial packaging is allowed when needed to enable the test. Final packaging and release must respect the agreed gates and current authorization. A published status requires evidence of publication; a download link alone is a delivery artifact.

An explicit user change to the acceptance process has authority over this default. Record any waiver or revised scope as a change, including remaining uncertainty, rather than fabricating successful user testing. Do not repeatedly seek authorization already granted for the exact action and scope.
