# Results, measurements, and scoring

Use this reference when drafting/revising KRs, reviewing results, or calculating progress. These are decision aids, not quotas.

## Select a meaningful result

| Candidate | Problem to examine | Better evidence for the intended outcome |
|---|---|---|
| Publish ten help articles | Output count can rise without anyone succeeding | Representative readers complete the intended task using the guidance, under stated conditions. |
| All automated tests pass | Can miss the wrong workflow or misunderstood output | Relevant technical checks plus actual use of the agreed task and recovery path. |
| Launch a dashboard | File existence is not operational usefulness | The intended operator uses the specified data to answer the agreed decision question correctly. |
| Increase adoption by 20% | Ambiguous denominator, baseline, and attribution | Define eligible users, meaningful usage, baseline period, measurement window, and competing explanations. |
| Decide whether a prototype is feasible | A justified learning milestone can be useful | Predefine the experiment, decision criterion, evidence, and what would falsify feasibility. |

Do not automatically reject binary capability KRs. A prototype that demonstrates a previously unproven capability under explicit conditions can be a meaningful result. Explain why that capability or learning matters now and how later impact would be measured. Keep implementation tasks separate from proof of capability.

For each numeric metric, specify unit, numerator/denominator, eligible population, direction, observation window, and source as applicable. Different environments or populations are not automatically comparable. Sample sizes, thresholds, and deadlines must come from the user, evidence, or a clearly labeled proposal; do not invent agreement.

If the baseline is missing, write `unknown / measurement pending`, identify the measurement action and owner, and avoid a numeric progress claim. Continue work that does not depend on that number. Distinguish unavailable data from a measured zero. Do not manufacture historical values from memory or a target.

## Score the agreed definition

For a numeric KR defined as movement from baseline B toward target T, with observed value A:

`raw_progress = (A - B) / (T - B)`

This applies to both increases and decreases when the quantities are comparable and T differs from B. If displaying bounded progress, clamp to 0–100% but retain actual values and flag regression or overshoot. It is not a universal formula for thresholds, ranges, nonlinear utilities, or qualitative learning.

| Baseline → target; observed | Interpretation |
|---|---|
| 40% → 60%; 50% | 50% of the intended improvement. |
| 10 minutes → 2 minutes; 6 minutes | 50% of the intended reduction. |
| 10 minutes → 2 minutes; 12 minutes | Raw progress −25%; show regression even if the display is clamped to 0%. |
| Unknown → 60%; 50% | Current value known; baseline-relative progress unavailable. |
| Maintain at least 99.9% for a month | Judge the agreed threshold over that window; B=T is not a valid denominator. |
| A representative task can be completed independently | Apply the stated capability test; incomplete observations remain pending, not an invented 50%. |

Use `A / T` only if a genuine zero-baseline accumulation metric makes that definition appropriate. Do not use it for reducing errors, duration, cost, or other decreasing metrics.

Keep these separate:

- **Observed result:** the measured value or demonstrated capability, with source and conditions.
- **Progress:** movement against the agreed definition; may be unavailable.
- **Forecast/confidence:** an explicitly labeled assessment of future attainment, with reasons.
- **Status:** on track, at risk, blocked, achieved, not achieved, or pending evidence; justify it without inventing numerical confidence.

A committed KR succeeds when its agreed requirement is met. An aspirational KR can provide useful learning below target, but do not automatically call 70% success or excuse failed acceptance. Avoid objective averages by default; if an aggregate is explicitly useful, show its weighting, unknown components, and individual results. Critical guardrails and required human acceptance remain visible and cannot be averaged away.

## Review changes and sufficiency

Revisit “Could all KRs pass while the objective still fails?” Examples: fast task completion achieved by silently dropping data, a complete report that its audience cannot understand, or a high click rate that harms qualified outcomes. Add the missing observable outcome or necessary guardrail, not arbitrary extra metrics.

When the environment changes, retain the original KR/target, record the reason and the user's decision or delegated authority for the revision, and distinguish original attainment from revised attainment. A failed measurement method may need repair; it is not permission to lower the target.

At retrospective, report attained results, unresolved evidence, unsuccessful assumptions, and one useful adjustment. Do not invent a recurring meeting or scheduled measurement task without a user request.
