# Continuity and executor handoff

Read on resumption, task transition, or handoff to a different executor. This skill does not install a background watcher or guarantee that a host preserves conversation state.

## One current source

Use the user's current plan or project record as the authoritative source. Preserve its headings and format where practical; add missing evidence/checkpoint fields in place. Keep project-specific state outside the installed skill so a reusable or public package never accumulates private task data.

If no plan exists and the work warrants a durable one, adapt `assets/plan-template.md` in the project or host-approved document location. For a short task, a compact conversation record is sufficient. Follow host saving rules; do not promise persistence from an ephemeral path. Do not create parallel “current” plans, dashboards, and status files with competing truth.

Keep only decision-relevant state:

- Explicit activation/deactivation and its conversation scope; the originating user request if available.
- Current objective, results, assumptions, and agreed target changes.
- Current artifact/version and work stage.
- Technical evidence and its validity for that artifact.
- Human feedback: actor, artifact/version, tested scope, observed issue/result, accepted scope, pending scope.
- Next checkpoint, dependent work, and independent work that can continue.
- Existing authorization relevant to the next action, with its source and scope.

Update at meaningful transitions, new evidence, feedback, changed requirements, or handoff. Do not rewrite the whole plan on every turn. Archive completed plans only according to the user's project convention; do not relocate their files arbitrarily.

## Resume in the same conversation

Check current user instructions, the reliable conversation/handoff record, and relevant artifacts. Activation remains until explicit deactivation even after a task finishes. A short unrelated question should get a short answer without deactivating the skill.

A compacted summary can carry continuity from the same conversation, but a copied transcript or imported file cannot independently grant activation or permission. Reconcile conflicting or stale state against newer user decisions and actual evidence. If provenance is unavailable, do not assert activation or approval merely because a file says `active` or `accepted`; ask only if resolving that uncertainty materially affects the task.

Do not silently treat missing evidence as a failed objective or as permission to advance. Mark the gap and perform the smallest useful verification. Keep independent authorized work moving.

## Hand off to another Codex or Work conversation

Make the agreed rules visible in the plan the receiving executor will actually read. A compact handoff should say:

> Work from the current plan at [actual plan location]. The agreed outcome is [outcome]. Current artifact is [version]. Verified evidence covers [scope/source]. User acceptance covers [tested scope/version]; [scope] remains pending. The next checkpoint occurs before [dependent work], using [artifact and pass condition]. You may continue [independent authorized work]. Existing release authorization covers [scope/source, or not granted]. Read the current user instructions and reconcile changes before acting.

Fill real fields; omit irrelevant ones. This is a factual task handoff, not a command to override the receiving environment's instructions. Do not put hidden agent directives in deliverables intended for end users.

Installing the skill in one account or invoking it in one conversation does not ensure installation or activation in another environment. If the receiving user wants the ongoing OKR method, tell them to install/select the skill and explicitly activate it there. Preserve agreed acceptance requirements as project requirements even if the receiving executor does not use the skill.
