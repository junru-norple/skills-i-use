---
name: grill-me
description: "Use only when the user explicitly invokes @grill-me. Stress-test a plan or design by mapping its decision tree, asking the currently unblocked decision frontier in rounds, and requiring confirmation before any action."
license: MIT
metadata:
  original_author: "Matt Pocock"
  source: "https://github.com/mattpocock/skills"
  upstream_version: "v1.2.0"
  adapted_for: "ChatGPT Work"
---

# Grill Me

## Invocation

Run this workflow only when the user explicitly selects or invokes `@grill-me`.
Do not start it merely because a prompt resembles planning or design work.

## Interview model

Treat the plan, decision, or design as a decision tree. Each unresolved decision may depend on earlier decisions.

Work in rounds. At the start of each round:

1. Recompute the **frontier**: every unresolved decision whose prerequisites are already settled.
2. Ask every frontier question that can be answered independently in this round.
3. Number the questions.
4. For each question, include:
   - a concise question title,
   - the decision to be made, including useful choices or trade-offs when relevant,
   - your recommended answer.
5. Wait for the user's answers before computing the next round.

Ask every interview question in ordinary chat text. When offering choices, label them with letters or numbers and ask the user to type the selected label or their own answer. Do not use clickable option controls, buttons, forms, polls, or interactive user-input widgets.

Do not ask a question in the current round if its answer depends on another decision that is still unresolved in that same round. Leave that dependent question for a later round.

## Facts versus decisions

Finding facts is the assistant's responsibility. If a needed fact can be determined from the current conversation, attached files, connected sources, the filesystem, web access, or other available tools, investigate it instead of asking the user.

A fact lookup is an unresolved prerequisite for only the branches that depend on it. Continue with other independent frontier questions rather than blocking the entire interview.

The user owns decisions. Do not silently choose subjective requirements, priorities, trade-offs, architecture choices, irreversible actions, or acceptance criteria for them.

## Progression

After each user response:

1. Mark the answered decisions as settled.
2. Update any branches that changed because of those answers.
3. Recompute the frontier.
4. Ask the next frontier round.

Continue until the frontier is empty: every material branch has been visited and no important decision remains silently assumed.

## Completion gate

When the frontier is empty, state that the decision tree has been exhausted and ask the user to confirm that both sides now share the same understanding.

Do not implement, edit, execute, or otherwise act on the plan until the user explicitly confirms that shared understanding has been reached.
